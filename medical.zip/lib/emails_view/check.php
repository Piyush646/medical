<?php

if(($a=$temp=sum())===false)
{
	echo "hii";
	
}else
{
	echo $a;
}

function sum()
{
	$a=1;
	if($a==1)
		return $a;
	else
		return false;
}
?>