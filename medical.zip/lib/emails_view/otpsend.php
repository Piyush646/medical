<!--OTP VALUE -> TO BE REPLACED WITH OTP VALUE-->

<div style="height:100%;margin:0;padding:0;width:100%;background-color:#fafafa"><div class="adM">
        
        </div><center>
            <table id="m_-2796604392760759110m_-2863066029000629026bodyTable" style="border-collapse:collapse;height:100%;margin:0;padding:0;width:100%;background-color:#fafafa" width="100%" height="100%" cellspacing="0" cellpadding="0" border="0" align="center">
                <tbody><tr>
                    <td id="m_-2796604392760759110m_-2863066029000629026bodyCell" style="height:100%;margin:0;padding:10px;width:100%;border-top:0" valign="top" align="center">
                        
                        
                        <table class="m_-2796604392760759110m_-2863066029000629026templateContainer" style="border-collapse:collapse;border:0;max-width:600px!important" width="100%" cellspacing="0" cellpadding="0" border="0">
                            <tbody><tr>
                                <td id="m_-2796604392760759110m_-2863066029000629026templatePreheader" style="background:#fafafa none no-repeat center/cover;background-color:#fafafa;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:9px;padding-bottom:9px" valign="top"><table class="m_-2796604392760759110m_-2863066029000629026mcnTextBlock" style="min-width:100%;border-collapse:collapse" width="100%" cellspacing="0" cellpadding="0" border="0">
    <tbody class="m_-2796604392760759110m_-2863066029000629026mcnTextBlockOuter">
        <tr>
            <td class="m_-2796604392760759110m_-2863066029000629026mcnTextBlockInner" style="padding-top:9px" valign="top">
              	
			
				
                <table style="max-width:100%;min-width:100%;border-collapse:collapse" class="m_-2796604392760759110m_-2863066029000629026mcnTextContentContainer" width="100%" cellspacing="0" cellpadding="0" border="0" align="left">
                    <tbody><tr>

                        <td class="m_-2796604392760759110m_-2863066029000629026mcnTextContent" style="padding:0px 18px 9px;text-align:center;word-break:break-word;color:#656565;font-family:Helvetica;font-size:12px;line-height:150%" valign="top">

                            <hr><span style="font-size:12px"><span style="color:#ff0000"><i><b>OTP For Shvetdhara Store Registration</b></i></span></span>

<hr>
                        </td>
                    </tr>
                </tbody></table>
				

				
            </td>
        </tr>
    </tbody>
</table></td>
                            </tr>
                            <tr>
                                <td id="m_-2796604392760759110m_-2863066029000629026templateHeader" style="background:#ffffff none no-repeat center/cover;background-color:#ffffff;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:9px;padding-bottom:0" valign="top"><table class="m_-2796604392760759110m_-2863066029000629026mcnImageBlock" style="min-width:100%;border-collapse:collapse" width="100%" cellspacing="0" cellpadding="0" border="0">
    <tbody class="m_-2796604392760759110m_-2863066029000629026mcnImageBlockOuter">
            <tr>
                <td style="padding:9px" class="m_-2796604392760759110m_-2863066029000629026mcnImageBlockInner" valign="top">
                    <table class="m_-2796604392760759110m_-2863066029000629026mcnImageContentContainer" style="min-width:100%;border-collapse:collapse" width="100%" cellspacing="0" cellpadding="0" border="0" align="left">
                        <tbody><tr>
                            <td class="m_-2796604392760759110m_-2863066029000629026mcnImageContent" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center" valign="top">


                                        <img alt="" src="https://shvetdhara.com/vendor/admin/uploads/1547311269_1540589603_1530473131_SHVETDHARA%20LOGO%20FINAL.png" style="padding-bottom:0px;display:inline!important;vertical-align:bottom;border:0px none;outline:currentcolor none medium;text-decoration:none;margin-right:0px" class="m_-2796604392760759110m_-2863066029000629026mcnImage CToWUd" width="153" height="140" align="middle">


                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table></td>
                            </tr>
                            <tr>
                                <td id="m_-2796604392760759110m_-2863066029000629026templateBody" style="background:#ffffff none no-repeat center/cover;background-color:#ffffff;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:2px solid #eaeaea;padding-top:0;padding-bottom:9px" valign="top"><table class="m_-2796604392760759110m_-2863066029000629026mcnTextBlock" style="min-width:100%;border-collapse:collapse" width="100%" cellspacing="0" cellpadding="0" border="0">
    <tbody class="m_-2796604392760759110m_-2863066029000629026mcnTextBlockOuter">
        <tr>
            <td class="m_-2796604392760759110m_-2863066029000629026mcnTextBlockInner" style="padding-top:9px" valign="top">
              	
			
				
                <table style="max-width:100%;min-width:100%;border-collapse:collapse" class="m_-2796604392760759110m_-2863066029000629026mcnTextContentContainer" width="100%" cellspacing="0" cellpadding="0" border="0" align="left">
                    <tbody><tr>

                        <td class="m_-2796604392760759110m_-2863066029000629026mcnTextContent" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;word-break:break-word;color:#202020;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left" valign="top"><span class="im">

                            <p style="margin:10px 0;padding:0;color:#202020;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left"><span style="color:#000000"><span style="font-size:12px"><b><i>Dear Seller,</i></b></span></span></p>

<p style="margin:10px 0;padding:0;color:#202020;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left"><span style="color:#000000"><span style="font-size:12px"><b><i>Greetings from Shvetdhara.</i></b></span></span></p>

</span><p style="margin:10px 0;padding:0;color:#202020;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left"><span style="color:#000000"><span style="font-size:12px"><b><i>Your OTP for registration is OTP VALUE. Use this password to validate your login. Kindly do not share this OTP with anyone else for security reasons.</i></b></span></span></p>

                        </td>
                    </tr>
                </tbody></table>
				

				
            </td>
        </tr>
    </tbody>
</table></td>
                            </tr>
                            <tr>
                                <td id="m_-2796604392760759110m_-2863066029000629026templateFooter" style="background:#fafafa none no-repeat center/cover;background-color:#fafafa;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:9px;padding-bottom:9px" valign="top"><table class="m_-2796604392760759110m_-2863066029000629026mcnFollowBlock" style="min-width:100%;border-collapse:collapse" width="100%" cellspacing="0" cellpadding="0" border="0">
    <tbody class="m_-2796604392760759110m_-2863066029000629026mcnFollowBlockOuter">
        <tr>
            <td style="padding:9px" class="m_-2796604392760759110m_-2863066029000629026mcnFollowBlockInner" valign="top" align="center">
                <table class="m_-2796604392760759110m_-2863066029000629026mcnFollowContentContainer" style="min-width:100%;border-collapse:collapse" width="100%" cellspacing="0" cellpadding="0" border="0">
    <tbody><tr>
        <td style="padding-left:9px;padding-right:9px" align="center">
            <table style="min-width:100%;border-collapse:collapse" class="m_-2796604392760759110m_-2863066029000629026mcnFollowContent" width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody><tr>
                    <td style="padding-top:9px;padding-right:9px;padding-left:9px" valign="top" align="center">
                        <table style="border-collapse:collapse" cellspacing="0" cellpadding="0" border="0" align="center">
                            <tbody><tr>
                                <td valign="top" align="center">
                                    

                                        


                                            <table style="display:inline;border-collapse:collapse" cellspacing="0" cellpadding="0" border="0" align="left">
                                                <tbody><tr>
                                                    <td style="padding-right:10px;padding-bottom:9px" class="m_-2796604392760759110m_-2863066029000629026mcnFollowContentItemContainer" valign="top">
                                                        <table class="m_-2796604392760759110m_-2863066029000629026mcnFollowContentItem" style="border-collapse:collapse" width="100%" cellspacing="0" cellpadding="0" border="0">
                                                            <tbody><tr>
                                                                <td style="padding-top:5px;padding-right:10px;padding-bottom:5px;padding-left:9px" valign="middle" align="left">
                                                                    <table style="border-collapse:collapse" width="" cellspacing="0" cellpadding="0" border="0" align="left">
                                                                        <tbody><tr>

                                                                                <td class="m_-2796604392760759110m_-2863066029000629026mcnFollowIconContent" width="24" valign="middle" align="center">
                                                                                    <a href="https://www.facebook.com/shvetdharadairyfoods/" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://www.facebook.com/shvetdhara.com/?modal%3Dadmin_todo_tour&amp;source=gmail&amp;ust=1564137616786000&amp;usg=AFQjCNFNpwgzN_98Xcu5bEBYp8liUfSs1w"><img src="https://ci5.googleusercontent.com/proxy/KLWDyxU_2JT5nOGTE6_NSp-hT37kpCU8B8HLih6GyBnhKJEvCDQsIeq4uLfJ7CQWsSCfpfcbCXVh74IrAuFYiXcU4R2sPN1CInMYwE7DpPIiYM9dGmBbl7FrtmeFZ6I=s0-d-e1-ft#https://cdn-images.mailchimp.com/icons/social-block-v2/color-facebook-48.png" alt="Facebook" style="display:block;border:0;height:auto;outline:none;text-decoration:none" class="CToWUd" width="24" height="24"></a>
                                                                                </td>


                                                                        </tr>
                                                                    </tbody></table>
                                                                </td>
                                                            </tr>
                                                        </tbody></table>
                                                    </td>
                                                </tr>
                                            </tbody></table>

                                        

                                        


                                            <table style="display:inline;border-collapse:collapse" cellspacing="0" cellpadding="0" border="0" align="left">
                                                <tbody><tr>
                                                    <td style="padding-right:10px;padding-bottom:9px" class="m_-2796604392760759110m_-2863066029000629026mcnFollowContentItemContainer" valign="top">
                                                        <table class="m_-2796604392760759110m_-2863066029000629026mcnFollowContentItem" style="border-collapse:collapse" width="100%" cellspacing="0" cellpadding="0" border="0">
                                                            <tbody><tr>
                                                                <td style="padding-top:5px;padding-right:10px;padding-bottom:5px;padding-left:9px" valign="middle" align="left">
                                                                    <table style="border-collapse:collapse" width="" cellspacing="0" cellpadding="0" border="0" align="left">
                                                                        <tbody><tr>

                                                                                <td class="m_-2796604392760759110m_-2863066029000629026mcnFollowIconContent" width="24" valign="middle" align="center">
                                                                                    <a href="https://shvetdhara.com/" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://www.shvetdhara.com/&amp;source=gmail&amp;ust=1564137616787000&amp;usg=AFQjCNEUQlR2jsLNrT9XOC6OkneUN2icdA"><img src="https://ci5.googleusercontent.com/proxy/FR4I0VM10pxcUwbQ63iIF6cAOqyzEbM1yC4ru84XQ1cT1RbvvmtJzUt4RdH1WUB452ecisGFRwh877ppJp5BhUmQhUWIABs5JUY80JFlBF08huivKdmS6R-dPg=s0-d-e1-ft#https://cdn-images.mailchimp.com/icons/social-block-v2/color-link-48.png" alt="Website" style="display:block;border:0;height:auto;outline:none;text-decoration:none" class="CToWUd" width="24" height="24"></a>
                                                                                </td>


                                                                        </tr>
                                                                    </tbody></table>
                                                                </td>
                                                            </tr>
                                                        </tbody></table>
                                                    </td>
                                                </tr>
                                            </tbody></table>

                                        

                                        


                                            <table style="display:inline;border-collapse:collapse" cellspacing="0" cellpadding="0" border="0" align="left">
                                                <tbody><tr>
                                                    <td style="padding-right:0;padding-bottom:9px" class="m_-2796604392760759110m_-2863066029000629026mcnFollowContentItemContainer" valign="top">
                                                        <table class="m_-2796604392760759110m_-2863066029000629026mcnFollowContentItem" style="border-collapse:collapse" width="100%" cellspacing="0" cellpadding="0" border="0">
                                                            <tbody><tr>
                                                                <td style="padding-top:5px;padding-right:10px;padding-bottom:5px;padding-left:9px" valign="middle" align="left">
                                                                    <table style="border-collapse:collapse" width="" cellspacing="0" cellpadding="0" border="0" align="left">
                                                                        <tbody><tr>

                                                                                <td class="m_-2796604392760759110m_-2863066029000629026mcnFollowIconContent" width="24" valign="middle" align="center">
                                                                                    <a href="https://shvetdhara.com/" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://www.instagram.com/shvetdhara.com/?hl%3Den&amp;source=gmail&amp;ust=1564137616787000&amp;usg=AFQjCNHtMAgnkvRSXUH7m6zr-Z0xwxU5KQ"><img src="https://ci3.googleusercontent.com/proxy/Kxmv_VOWHxRbx9ha8NMR9nONZZkGxv2vyrUOlpQhi5_ieDBEPqRomk1Twd6kvqAcUM1ccGIxTgC8Rh1TvQcdKf-Ql5F87HSw4DKkcKIdL9Gz-WFmaHDWBrvzjPHt2CVn=s0-d-e1-ft#https://cdn-images.mailchimp.com/icons/social-block-v2/color-instagram-48.png" alt="Instagram" style="display:block;border:0;height:auto;outline:none;text-decoration:none" class="CToWUd" width="24" height="24"></a>
                                                                                </td>


                                                                        </tr>
                                                                    </tbody></table>
                                                                </td>
                                                            </tr>
                                                        </tbody></table>
                                                    </td>
                                                </tr>
                                            </tbody></table>

                                        

                                    
                                </td>
                            </tr>
                        </tbody></table>
                    </td>
                </tr>
            </tbody></table>
        </td>
    </tr>
</tbody></table>

            </td>
        </tr>
    </tbody>
</table><table class="m_-2796604392760759110m_-2863066029000629026mcnDividerBlock" style="min-width:100%;border-collapse:collapse;table-layout:fixed!important" width="100%" cellspacing="0" cellpadding="0" border="0">
    <tbody class="m_-2796604392760759110m_-2863066029000629026mcnDividerBlockOuter">
        <tr>
            <td class="m_-2796604392760759110m_-2863066029000629026mcnDividerBlockInner" style="min-width:100%;padding:10px 18px 25px">
                <table class="m_-2796604392760759110m_-2863066029000629026mcnDividerContent" style="min-width:100%;border-top:2px solid #ff0707;border-collapse:collapse" width="100%" cellspacing="0" cellpadding="0" border="0">
                    <tbody><tr>
                        <td>
                            <span></span>
                        </td>
                    </tr>
                </tbody></table>

            </td>
        </tr>
    </tbody>
</table><table class="m_-2796604392760759110m_-2863066029000629026mcnTextBlock" style="min-width:100%;border-collapse:collapse" width="100%" cellspacing="0" cellpadding="0" border="0">
    <tbody class="m_-2796604392760759110m_-2863066029000629026mcnTextBlockOuter">
        <tr>
            <td class="m_-2796604392760759110m_-2863066029000629026mcnTextBlockInner" style="padding-top:9px" valign="top">
              	
			
				
                <table style="max-width:100%;min-width:100%;border-collapse:collapse" class="m_-2796604392760759110m_-2863066029000629026mcnTextContentContainer" width="100%" cellspacing="0" cellpadding="0" border="0" align="left">
                    <tbody><tr>

                        <td class="m_-2796604392760759110m_-2863066029000629026mcnTextContent" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;word-break:break-word;color:#656565;font-family:Helvetica;font-size:12px;line-height:150%;text-align:center" valign="top">

                            <span style="color:#000000"><i><b>Regards,<br>
Shvetdhara India,</b></i></span>
                        </td>
                    </tr>
                </tbody></table>
				

				
            </td>
        </tr>
    </tbody>
</table></td>
                            </tr>
                        </tbody></table>
                        
                        
                    </td>
                </tr>
            </tbody></table></center><center><table id="m_-2796604392760759110m_-2863066029000629026canspamBarWrapper" style="background-color:#ffffff;border-top:1px solid #e5e5e5" width="100%" cellspacing="0" cellpadding="0" border="0">
                    <tbody><tr>
                        <td style="padding-top:20px;padding-bottom:20px" valign="top" align="center">
                            <table id="m_-2796604392760759110m_-2863066029000629026canspamBar" cellspacing="0" cellpadding="0" border="0">
                                <tbody><tr>
                                    <td style="color:#606060;font-family:Helvetica,Arial,sans-serif;font-size:11px;line-height:150%;padding-right:20px;padding-bottom:5px;padding-left:20px;text-align:center" valign="top" align="center"><br>
                                        <br>
                                    </td>
                                </tr>
                            </tbody></table>
                        </td>
                    </tr>
                </tbody></table>
                
            </center></div>