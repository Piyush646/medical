<!--WEBSITE LOGO HERE -> TO BE REPLACE WITH LOGO -->
<!--SHOP NAME HERE -> TO BE REPLACED WITH SHOP NAME-->
<!--USER NAME HERE -> TO BE REPLACED WITH USER NAME-->
<!--USER EMAIL HERE -> TO BE REPLACED WITH USER EMAIL-->
<!DOCTYPE html>
<html> 
  <table id="yiv2635011109container" style="width:640px;color:rgb(51, 51, 51);margin:0 auto;border-collapse:collapse;"> 
   <tbody>
    <tr> 
     <td class="yiv2635011109frame" style="padding:0 20px 20px 20px;vertical-align:top;font-size:13px;line-height:18px;font-family:Arial, sans-serif;"> 
      <table id="yiv2635011109main" style="width:100%;border-collapse:collapse;"> 
       <tbody>
        <tr> 
         <td style="vertical-align:top;font-size:13px;line-height:18px;font-family:Arial, sans-serif;"> 
          <table id="yiv2635011109header" style="width:100%;border-collapse:collapse;"> 
           <tbody>
            <tr> 
                <td rowspan="2" class="yiv2635011109logo" style="width:115px;padding:20px 20px 0 0;vertical-align:top;font-size:13px;line-height:18px;font-family:Arial, sans-serif;"> 
                 <a rel="nofollow" target="_blank" href="#"  style="text-decoration:none;color:rgb(0, 102, 153);font:12px/ 16px Arial, sans-serif;"> 
                     <img  src="WEBSITE LOGO HERE" alt="" style="border:0;width:115px;" class="yiv2635011109ycb8386705225"> 
                 </a> 
             </td> 
             <td class="yiv2635011109navigation" style="text-align:right;padding:5px 0;border-bottom:1px solid rgb(204, 204, 204);white-space:nowrap;vertical-align:top;font-size:13px;line-height:18px;font-family:Arial, sans-serif;"> 
             </td>
             <td style="width:100%;padding:7px 5px 0;text-align:right;border-bottom:1px solid rgb(204, 204, 204);white-space:nowrap;vertical-align:top;font-size:13px;line-height:18px;font-family:Arial, sans-serif;" class="yiv2635011109navigation"> 
                 
             </td> 
             <td class="yiv2635011109navigation" style="text-align:right;padding:5px 0;border-bottom:1px solid rgb(204, 204, 204);white-space:nowrap;vertical-align:top;font-size:13px;line-height:18px;font-family:Arial, sans-serif;"> 
                 
                 <span style="text-decoration:none;color:rgb(204, 204, 204);font-size:15px;font-family:Arial, sans-serif;">&nbsp;&nbsp;</span> <a rel="nofollow" class="yiv2635011109last" target="_blank" href="#" style="border:0;margin:0;padding:0;border-right:0px solid rgb(204, 204, 204);margin-right:0px;padding-right:0px;text-decoration:none;color:rgb(0, 102, 153);font:12px/ 16px Arial, sans-serif;">
                 
                 </a> 
             </td>  
            </tr> 
            <tr> 
             <td colspan="3" class="yiv2635011109title" style="text-align:right;padding:7px 0 5px 0;vertical-align:top;font-size:13px;line-height:18px;font-family:Arial, sans-serif;"> 
                 
                 <br> 
             </td> 
            </tr> 
           </tbody>
          </table> 
        </td> 
        </tr> 
        <tr> 
         <td style="vertical-align:top;font-size:13px;line-height:18px;font-family:Arial, sans-serif;"> 
          <table id="yiv2635011109summary" style="width:100%;border-collapse:collapse;"> 
           <tbody>
            <tr> 
             <td style="vertical-align:top;font-size:13px;line-height:18px;font-family:Arial, sans-serif;"> 
                 <h3 style="font-size:18px;color:rgb(204, 102, 0);margin:15px 0 0 0;font-weight:normal;">
                     Hello USER NAME HERE
                 </h3> <br/>
                 <p style="margin:0 0 4px 0;font:12px/ 16px Arial, sans-serif;"> 
                     Thank you for registration with Shvetdhara<br> Your login information is as follows:<br>
					 User Name is: USER EMAIL HERE<br>
					 Please click on the below link to Activate your account<br><br>
					 <a href='https://shvetdhara.com/login'>Login</a>
					 <br>If you have any problem please email us at <a href="mailto:info@shvetdhara.com">info@shvetdhara.com</a><br><br>
					 
                 </p>
             </td> 
			 </tr>
			<tr>
			 <td style="vertical-align:top;font-size:13px;line-height:18px;font-family:Arial, sans-serif;"> <p style="font-size:10px;color:rgb(102, 102, 102);line-height:16px;margin:0 0 10px 0;font:10px;"> This email was sent from a notification-only address that cannot accept incoming email. Please do not reply to this message. </p> </td> 

            </tr>
           </tbody>
          </table> </td> 
        </tr> 
           </tbody>
          </table> </td> 
        </tr> 
       </tbody>
      </table>
  </html>';
    